class ApplyJobs {
    ClickSearchButton() {
      cy.get('.nI-gNb-sb__placeholder').click();
    }
  
    EnterKeywordLocationAndExperience(searchKeyword, searchLocation) {
      cy.get('input.suggestor-input[placeholder="Enter keyword / designation / companies"]').type(searchKeyword);
      cy.get('input.suggestor-input[placeholder="Enter location"]').type(searchLocation);
      cy.get('#experienceDD').click();
      cy.get('.dropdownContainer').contains('5 years').click();
      cy.get('.nI-gNb-sb__icon-wrapper').click();
    }
  
    ClickOnAllJobLinks() {
      // Ensure the job list container is visible before proceeding
      cy.get('.cust-job-tuple .title').should('be.visible');
  
      // Get all job title links and iterate over them
      cy.get('a.title').each(($el) => {
        // Extract the href attribute and print it
        const href = $el.prop('href');
        cy.log(`Job Link: ${href}`); // Print the href attribute
  
        // Visit the job link after verifying page load
        cy.visit(href, {
          headers: { "Accept-Encoding": "gzip, deflate" }
        });
  
        // Check if #apply-button is present
        cy.get('#apply-button').then($applyButton => {
          // If #apply-button is present, check its text and click if it says "Apply"
          if ($applyButton.length > 0) {
            const buttonText = $applyButton.text().trim();
            if (buttonText === 'Apply') {
              cy.wrap($applyButton).click();
            }
          } else {
            // If #apply-button is not found, navigate back
            cy.go('back');
          }
        });
  
        // After processing each job link, navigate back to the search results
        cy.go('back');
      });
    }
  }
  
  export default new ApplyJobs();
  