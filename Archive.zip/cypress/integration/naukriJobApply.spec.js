
import LoginPage from '../support/naukri_login';
import ApplyJobs from '../support/applyJobs';

describe('Naukri Profile Apply Job', () => {
  const naukriusername = Cypress.env('naukriusername');
  const naukripassword = Cypress.env('naukripassword');
  const fileName = 'SuryaTejaTadaka_Resume1.pdf'; // Update with your actual file name

  beforeEach(() => {
    LoginPage.visit();
    LoginPage.clickLoginLayerButton();
    LoginPage.fillEmail(naukriusername);
    LoginPage.fillPassword(naukripassword);
    LoginPage.submitLoginForm();
  });
  it('should log in and apply to job', () => {
    ApplyJobs.ClickSearchButton();
    ApplyJobs.EnterKeywordLocationAndExperience("Python", "Hyderabad");
    ApplyJobs.ClickOnAllJobLinks();
  });
});
