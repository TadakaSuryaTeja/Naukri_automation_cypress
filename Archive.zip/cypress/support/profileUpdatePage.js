// cypress/support/profileUpdatePage.js

class ProfileUpdatePage {
    clickProfileIcon() {
      cy.get('.nI-gNb-drawer__icon-img-wrapper img[alt="naukri user profile img"]').click();
    }
  
    clickUpdateResumeLink() {
      cy.get('.nI-gNb-info__sub-link').click();
    }
  
    uploadResume(fileName) {
      cy.fixture(`cypress/fixtures/${fileName}`, 'base64').then(fileContent => {
        cy.get('.uploadCont > :nth-child(1)').attachFile({
          fileContent: fileContent,
          fileName: fileName,
          mimeType: 'application/pdf',
        });
      });
    }
  
    verifyUploadSuccessMessage() {
      cy.get('.cnt > .head').should('contain', 'success');
    }
  }
  
  export default new ProfileUpdatePage();
  