// cypress/support/loginPage.js

class LoginPage {
    visit() {
      cy.visit('https://www.naukri.com', {
        headers: { "Accept-Encoding": "gzip, deflate" }
      });
    }
  
    clickLoginLayerButton() {
      cy.get('#login_Layer').click();
    }
  
    fillEmail(username) {
      cy.get('input[placeholder="Enter your active Email ID / Username"]').type(username);
    }
  
    fillPassword(password) {
      cy.get('input[placeholder="Enter your password"]').type(password);
    }
  
    submitLoginForm() {
      cy.get('button[type="submit"].loginButton').click();
    }
  }
  
  export default new LoginPage();
  