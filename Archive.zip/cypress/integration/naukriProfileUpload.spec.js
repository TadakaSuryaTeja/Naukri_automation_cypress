// cypress/integration/naukriProfileUpload.spec.js

import LoginPage from '../support/naukri_login';
import ProfileUpdatePage from '../support/profileUpdatePage';

describe('Naukri Profile Upload Test', () => {
  const naukriusername = Cypress.env('naukriusername');
  const naukripassword = Cypress.env('naukripassword');
  const fileName = 'SuryaTejaTadaka_Resume1.pdf'; // Update with your actual file name

  beforeEach(() => {
    LoginPage.visit();
    LoginPage.clickLoginLayerButton();
    LoginPage.fillEmail(naukriusername);
    LoginPage.fillPassword(naukripassword);
    LoginPage.submitLoginForm();
    cy.get('.nI-gNb-drawer__icon-img-wrapper img[alt="naukri user profile img"]').should('be.visible');
  });

  it('should log in and upload a PDF file to the profile', () => {
    ProfileUpdatePage.clickProfileIcon();
    ProfileUpdatePage.clickUpdateResumeLink();
    ProfileUpdatePage.uploadResume(fileName);
    ProfileUpdatePage.verifyUploadSuccessMessage();
  });
});
